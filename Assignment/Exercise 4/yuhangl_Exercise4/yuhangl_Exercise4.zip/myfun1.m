function F=myfun1(x)
% for this question, we define a=3 and b=5.
a = -3;
b = 5;
F = [a*x(1)*x(2)-1;
    x(1)+b*x(2)];
